<?php
/**
 * Plugin Name: FBF Athena Bridge
 * Description: Read-only coach endpoint that gives Athena (Bryan's FBF Command Center) each client's current plan — program, daily macro targets, meal plan, supplements/protocol and training week. Uses the FBF Coach Hub's coach permissions; never generates or changes anything.
 * Version: 1.0.0
 * Author: Forged by Freedom
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

final class FBFAthena_Bridge
{
    const NS = 'fbf/v1';

    public static function init()
    {
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    public static function routes()
    {
        register_rest_route(self::NS, '/coach/clients/(?P<id>\d+)/plan', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'plan'],
            'permission_callback' => '__return_true', // checked inside, with the Coach Hub's rules
        ]);
        register_rest_route(self::NS, '/athena/status', [
            'methods'             => 'GET',
            'callback'            => function () {
                return ['ok' => true, 'plugin' => 'fbf-athena-bridge', 'version' => '1.0.0', 'coach_hub' => class_exists('FBFHub_Auth')];
            },
            'permission_callback' => '__return_true',
        ]);
    }

    /** Same coach rules as the FBF Coach Hub: head coach sees everyone, coaches see their assigned clients. */
    private static function coach_for(WP_REST_Request $req, $client_id)
    {
        if (!class_exists('FBFHub_Auth')) {
            return new WP_Error('fbf_athena_no_hub', 'FBF Coach Hub plugin must be active.', ['status' => 500]);
        }
        $coach = FBFHub_Auth::user_id($req);
        if (!$coach) {
            return new WP_Error('fbfhub_unauthorized', 'Sign in again.', ['status' => 401]);
        }
        if (!FBFHub_Auth::is_coach($coach)) {
            return new WP_Error('fbf_athena_forbidden', 'Coaches only.', ['status' => 403]);
        }
        if (!get_userdata($client_id) || !FBFHub_Auth::can_view_client($coach, $client_id)) {
            return new WP_Error('fbf_athena_forbidden', 'Not your client.', ['status' => 403]);
        }
        return (int) $coach;
    }

    private static function num($v)
    {
        return is_numeric($v) ? (float) $v : null;
    }

    /** Average daily calories/macros across the cached 7-day meal plan. */
    private static function daily_targets($days)
    {
        $tot = ['calories' => 0, 'protein_g' => 0, 'carbs_g' => 0, 'fat_g' => 0];
        $n = 0;
        foreach ((array) $days as $day) {
            $meals = isset($day['meals']) && is_array($day['meals']) ? $day['meals'] : [];
            if (!$meals) {
                continue;
            }
            $n++;
            foreach ($meals as $m) {
                foreach ($tot as $k => $_) {
                    $v = self::num($m[$k] ?? null);
                    if ($v !== null) {
                        $tot[$k] += $v;
                    }
                }
            }
        }
        if (!$n) {
            return null;
        }
        $out = ['days_in_plan' => $n];
        foreach ($tot as $k => $v) {
            $out[$k] = (int) round($v / $n);
        }
        return $out;
    }

    public static function plan(WP_REST_Request $req)
    {
        $cid   = (int) $req['id'];
        $coach = self::coach_for($req, $cid);
        if (is_wp_error($coach)) {
            return $coach;
        }

        $final   = (string) get_user_meta($cid, 'fbf_program_final', true);
        $draft   = (string) get_user_meta($cid, 'fbf_program_draft', true);
        $program = $final !== '' ? $final : $draft;

        $meal = get_user_meta($cid, 'fbf_mealplan_json', true);
        $meal_days = is_array($meal) && isset($meal['days']) && is_array($meal['days']) ? $meal['days'] : [];
        $supps = is_array($meal) && isset($meal['supplements']) && is_array($meal['supplements']) ? $meal['supplements'] : [];

        $wo = get_user_meta($cid, 'fbf_workoutplan_json', true);
        $wo_days = is_array($wo) && isset($wo['days']) && is_array($wo['days']) ? $wo['days'] : [];

        // The app builds the meal plan from fbf_program_draft and tags it md5('mp5|' . program).
        // If the program changed since, the app rebuilds it on next open — flag that so Athena knows.
        $meal_current = (is_array($meal) && isset($meal['hash']) && $draft !== '') ? hash_equals(md5('mp5|' . $draft), (string) $meal['hash']) : null;

        $levels = function_exists('pmpro_getMembershipLevelForUser') ? pmpro_getMembershipLevelForUser($cid) : null;

        return rest_ensure_response([
            'client'         => ['id' => $cid, 'name' => FBFHub_Auth::name($cid)],
            'membership'     => $levels && !empty($levels->name) ? $levels->name : null,
            'program_source' => $final !== '' ? 'final' : ($draft !== '' ? 'draft' : null),
            'program_text'   => $program !== '' ? $program : null,
            'daily_targets'  => self::daily_targets($meal_days),
            'meal_plan'      => $meal_days ?: null,
            'supplements'    => $supps ?: null,
            'training_week'  => $wo_days ?: null,
            'meal_plan_current' => $meal_current,
            'generated_at'   => gmdate('c'),
        ]);
    }
}

FBFAthena_Bridge::init();
